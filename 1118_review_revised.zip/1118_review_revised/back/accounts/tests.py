from django.shortcuts import render

# Create your views here.

# vue 에서 계정 관련 인증 (settings.py 수정 필요)