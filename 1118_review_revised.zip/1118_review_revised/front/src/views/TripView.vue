<template>
  <div>
    trip
  </div>
</template>

<script>
export default {
    name: 'TripView'
}
</script>

<style>

</style>