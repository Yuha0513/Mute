<template>
  <div>
    <select v-model="$i18n.locale">
      <option
        v-for="(lang, i) in langs"
        :key="`lang-${i}`"
        :value="lang"
      >
        {{ lang }}
      </option>
    </select>
  </div>
</template>

<script>
export default {
  name: 'SelectLocale',
  data() {
    return { langs: ['ko', 'en', 'zn', 'tw', 'ja'] } // 합본
    // return { langs: ['ko', 'en', 'zn', 'tw'] } // 유하
    // return { langs: ['ja'] } // 세진
  }
}
</script>