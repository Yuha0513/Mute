<template>
    <div class="reco_container">
        <swiper 
            class="swiper"
            :options="swiperOption"
            >
            <swiper-slide   swiper-slide
            v-for="recommand in Recommands"
            :key="recommand.id"
        >
        {{ recommand.title }}
        </swiper-slide>
      <div 
        class="swiper-pagination"
        slot="pagination"
      >
      </div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-button-next"></div>
    </swiper>
    <RecommandItem/>
  </div>
        


  
</template>


<script>
import RecommandItem from '@/components/Movie/RecommandItem'
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/css/swiper.css";

export default {
    name: 'RecommandMovie',
    components: {
        RecommandItem,
        Swiper,
        SwiperSlide,
    },
    methods: {
        getRecommand() {
            this.$store.dispatch('getRecommand')
        }
    },
    computed: {
        Recommands() {
            return this.$store.state.recommandMovie.movies
        }
    },
    created() {
        this.getRecommand()
    },
    swiperOption: { 
        slidesPerView: 1, 
        spaceBetween: 30, 
        loop: true, 
        pagination: { 
            el: '.swiper-pagination', 
            clickable: true 
        }, 
        navigation: { 
            nextEl: '.swiper-button-next', 
            prevEl: '.swiper-button-prev' 
        } 
    },

    
}
</script>

<style>
.reco_container {
    display: flex;
    width: 920px;
    height: auto;
    margin: 30px auto;
}

</style>