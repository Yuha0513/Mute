<template>
  <div> 좋아요 한 영화
    <div
      v-for="genre in genres"
      :key="genre.id"
    >
      <button @click="selectGenre(genre, $event)">{{ genre.name }}</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LikeList',
  data() {
    return {
      selected: '',
    }
  },
  created() {
    this.$store.dispatch('getLikeMovie')
    this.$store.dispatch('getGenre')
  },
  methods: {
    selectGenre(event) {
      this.$store.dispatch('selectGenre', event)
    }
  },
  computed: {
    genres() {
      return this.$store.state.genres
    }
  }
}
</script>

<style>

</style>