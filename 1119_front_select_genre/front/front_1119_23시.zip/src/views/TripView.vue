<template>
  <div>
    trip
    <div>

    </div>
  </div>
</template>

<script>


export default {
    name: 'TripView'
}
</script>

<style>
.flag_icon {
  width: 90px;
  height: 80px;
}
</style>