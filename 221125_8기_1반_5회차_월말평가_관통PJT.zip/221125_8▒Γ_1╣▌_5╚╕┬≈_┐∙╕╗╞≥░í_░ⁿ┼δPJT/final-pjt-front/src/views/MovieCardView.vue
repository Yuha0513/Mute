<template>
    <div>
        <div class="detail_body">
        <div class="second_body">
            <div class="movie_posterzone">
                <img :src=movie_poster width="400px">
            </div>
            <div class="movie_detail">
                <span class="movie_detail_title">{{movie?.title}}</span> 
                <span @click="postLikeMovies" class="fa-sharp fa-solid fa-heart" :style="`color:${this.$store.state.likecolor}`"></span>
                <span><button data-bs-toggle="modal" data-bs-target="#exampleModal1" id="englishbutton">English Overview</button></span>
                <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered ">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-4" id="exampleModalLabel">{{ englishtitle }}</h1>
                        <button type="button" class="btn-close btn-light" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <div>
                            <img :src="random_poster" width="200px" class="modal_img">
                            <p class="mt-4">
                            <span class="badge text-bg-success mx-1 mb-3" v-for="(ge, index) in genre" :key="index">{{ ge }}</span>
                            <!-- <span v-for="(ge, index) in genre" :key="index">{{ ge }} </span> -->
                            </p>
                            <p>{{ englishoverview }}</p>
                        </div>
                        
                        <!-- {{ random_country }} -->
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                    </div>
                </div>
                <hr>
                <p>
                    <MovieActor
                    v-for="(actor, index) in movie?.actors"
                    :key="index"
                    :actor="actor"
                    class="actor_name"
                />
                </p>
                <p class='movie_p'>{{ movie?.vote_average }}</p>
                <p class='movie_p'>{{ movie?.release_date }}</p>
                <p class='detail_overview'>{{ movie?.overview }}</p>
                
            </div>
        </div>
        <div class="third_body">
            <div class="bottom_youtubezone">
                <YoutubeList
                :movyoutube=movie?.title
                />
            </div>
        </div>
        <div class="forth_body">
            <div class="review_zone">
                <MovieReview
                :movieID="this.movie.id"
                />
            </div>
        </div>
    
        
    
        </div>
    </div>
  
</template>
  
<script>
import axios from 'axios'
import MovieReview from '@/components/Movie/MovieReview'
import YoutubeList from '@/components/Movie/YoutubeList'
import MovieActor from '@/components/Movie/MovieActor'

const API_URL = 'http://127.0.0.1:8000'
const API_KEY = '9da7ae64abaf7f23cd60ddbaebcfb205'
const URL = 'https://api.themoviedb.org/3/movie/'
// const movieid = 19995
  
export default {
    name: 'MovieCardView',
    data() {
        return {
            movie: null,
            movie_poster: null,
            movie_Youtube: null,
            movie_id: null,
            englishoverview: '',
            englishtitle: '',
        }
    },
methods: {
    getMovieDetail() {
        axios({
            method: 'get',
            url: `${API_URL}/movies/movies/${this.$route.params.id}`
        })
        .then((res) => {
            this.$store.dispatch('checkLikeMovie', res.data?.id)
            this.movie = res.data
            this.movie_Youtube = res.data.title
            this.movie_poster = `https://www.themoviedb.org/t/p/w600_and_h900_bestv2/${res.data?.poster_path}`
            this.movie_id = res.data?.id
            this.getEnglish(res.data.id)
            
        })
        .catch((err) => {
            console.log(err)
        })
    },
    postLikeMovies() {
    // const color = this.$store.state.likecolor
    this.$store.dispatch('postLikeMovies', this.movie)
    //   this.$store.dispatch('getLikeMovie')
    },
    checkColor() {
    // const color = this.$store.state.likecolor
        
    },
    getlikemovie() {
        this.$store.dispatch('getLikeMovie')
    },
    getEnglish() {
        const params = {
            api_key: API_KEY,
            language: 'en-US'
        }
        axios({
            method: 'get',
            url: `${URL}/${this.movie_id}`,
            params,
        })
        .then((res) => {
            console.log(res.data)
            this.englishoverview = res.data.overview
            this.englishtitle = res.data.title

        })
        .catch((err) => {
            console.log(err)
        })
    }
    
    },
    created() {
        this.getMovieDetail()
        this.movie_poster = `https://www.themoviedb.org/t/p/w600_and_h900_bestv2/${ this.movie?.poster_path }`
        this.getlikemovie()
    //   this.checkLike()
    },
    components: {
        MovieReview, YoutubeList, MovieActor
    },
    computed: {
        movieActor() {
            return this.movie.actors
        },
        likemovie() {
        return this.$store.state.like_movie
        },
        movieID() {
        return this.movie?.id
        },
        likeColored() {
        return this.$store.getters.like
        }
    },
}
</script>
  
<style>
.detail_body {
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.second_body {
    width: 1500px;
    margin-top: 60px;
    margin-bottom: 150px;
    margin-left: 33px;
    /* margin-left: px; */
}
.movie_posterzone{
    float: left;
    width: 400px;
    height: 500px;
    margin-right: 250px;
}
.movie_detail {
    margin-left: 400px;
    text-align: left;
    width: 800px;
    height: 500px;
}
.third_body {
    margin-bottom: 20px;
}
.movie_detail_title {
    margin-top: 25px;
    font-size: large;
    font-weight: bold;
    margin-bottom: 20px;
    margin-right: 20px;
}
.actor_name {
    margin-right: 5px;
    margin-top: 15px;
    margin-bottom: 20px;
}
.movie_p {
    margin-bottom: 7px;
}
.detail_overview {
    margin-top: 50px;
}
.liking {
    border: solid black;
    color:red;
}
#englishbutton{
    margin: 0;
    float: right;
}
</style>