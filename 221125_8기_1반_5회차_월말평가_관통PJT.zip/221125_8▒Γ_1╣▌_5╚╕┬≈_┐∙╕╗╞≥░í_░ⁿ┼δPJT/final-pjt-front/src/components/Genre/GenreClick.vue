<template>
  <div>
    
    
    <ul class="removeBulletAddTick">
      <!-- <p class="balloon">선택해주세요!</p> -->
      <p class="balloon">{{$t('message.gc2')}}</p>
      <li 
        v-for="(input, index) in legend_class" 
        :key="`input-${index}`"
      >

        <div class="legendElementWrapper"
          @click="sendFilterInput(input, index)"
        >
          <svg width="20" height="20">
            <rect :style="cssRectFill(input)" width="20" height="20"/>
          </svg>
          {{ input }}
        </div>
        
      </li>
    </ul>
  </div>
</template>

<script>
//import * as d3 from "d3";

export default {
  name: 'GenreClick',
  props: {
    data: Array,
    colorScale: null,
    },
  data: function() {
    return {
      legend_class: [],
      clickInput: [],
    }
  },
  created: function() {
    this.legend_class = this.data.map(a => a.Genre).filter((x, i, a) => a.indexOf(x) == i).sort(function(a, b){return parseFloat(a)-parseFloat(b)});
    this.clickInput = new Array(this.legend_class.length).fill(false)
  },
  mounted: function() {
  },
  methods: {
    sendFilterInput(input, index) {
      if ( this.clickInput[index] == false ) {
        this.clickInput[index] = true
        this.$emit('inputChange', input)
      } else if ( this.clickInput[index] == true ) {
        this.clickInput[index] = false
        this.$emit('inputChangeBack', input)
      }
    },
    cssRectFill(legItem) {
      return {
        '--fill': this.colorScale(legItem)
      }
    }
  },
  computed: {
  }
}
</script>

<style>
.removeBulletAddTick {
  text-align: left;
  /* margin-top: 10px; */
}
.legendElementWrapper {
  cursor: pointer;
}
rect {
  fill: var(--fill);
}
.balloon {
  position:relative;
  /* margin: 40px; */
  margin-left: 50px;
  margin-bottom: 40px;
  width:200px;
  height:50px;
  background:rgb(187, 232, 211);
  border-radius: 10px;
  color:black;
  text-align: center;
  padding-top: 13px;
  font-family: 'Do Hyeon', sans-serif;
  font-size: larger;
}
.balloon:after {
 border-top:0px solid transparent;
 border-left: 15px solid transparent;
 border-right: 0px solid transparent;
 border-bottom: 15px solid rgb(187, 232, 211);
 content:"";
 position:absolute;
 top:25px;
 left:-15px;
}
</style>