<template>
  <li>
    {{ countrymovie.title }}
  </li>
</template>

<script>
export default {
  name: 'TripSelectItem',
  props: {
    countrymovie: Object
  },
  
}
</script>

<style>

</style>