# pjtpjt

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

### install for d3

```
$ npm i d3-geo @1.11.9
$ npm install d3-geo@1.11.9
$ npm install d3-selection@1.4.1
$ npm install d3-zoom@1.8.3
```