<template>
  <div class="home_container">
    <div id="wrapper">
      <div id="home_content">
        
        <div>
          <div class="help-tip" id="home_help">
            <!-- <p>사용자 정보를 기반으로 한 추천입니다</p> -->
            <p>{{$t('message.hv1')}}</p>
          </div>
          <RecommandMovie/>
        </div>
        <div class="home_textarea">
          <p><strong>MUTE</strong></p>

          <!-- <p>안녕하세요. 무비 트립 플래너 Movie Trip Planner 무트 MUTE 입니다. </p> -->
          <p>{{$t('message.hv2')}}</p>

          <!-- <p>여행지에 도착하기까지의 시간이 지루하신가요? 어떤 준비를 하며 시간을 보내야 여행을 더 즐길 수 있을지 고민이신가요?</p> -->
          <p>{{$t('message.hv3')}}</p>

          <!-- <p>MUTE에서는 사용자 맞춤 영화 추천 서비스를 제공합니다.</p> -->
          <p>{{$t('message.hv4')}}</p>

          <!-- <p>혼자만의 작고 조용한 영화관, MUTE와 함께 경험해보세요.</p> -->
          <p>{{$t('message.hv5')}}</p>
          
        </div>
      </div>
    </div>
    <div class="home_user">
      <p><HomeUser/></p>
      <br>
      {{ userprofile }}
      <br> <br>
      <p><strong>New Info</strong></p>
      <!-- <p>{{ user }}</p> -->
    </div>
  </div>
</template>

<script>
import HomeUser from '@/components/User/HomeUser'
import RecommandMovie from '@/components/Movie/RecommandMovie'

export default {
  name: 'HomeView',
  components: {
    HomeUser, RecommandMovie
  },
  computed: {
    user() {
      return this.$store.state.user
    },
    userprofile() {
            return this.$store.state.userDetail.selfintroduce
        }
  },
  
}
</script>

<style>
/* @import 'scss/slide.scss'; */

html,body{margin:0;padding:0}

p{margin:0 10px 10px}
/* a{padding:5px; text-decoration:none; color:#000000;} */

div#header h1{height:80px;line-height:80px;margin:0;padding-left:10px;}

div#content p{line-height:1.4}
.home_footer{
  background:#BFBD93;
  margin:0;padding:5px 5px;
}

.home_container {

  width: 80%;
  margin:0 auto
}
#home_content{
  float:right;
  width:1000px;
  margin-right: 180px;
  /* margin-top: 30px; */
}

div#navigation{float:left;width:200px}
.home_user{
  display: flex;
  flex-direction: column;
  align-items: center;
  /* float:left; */
  clear:left;
  width:300px;
  margin-left:200px;
  margin-top: 110px;
  border: solid 1px rgb(150, 232, 195);
  border-radius: 30px;
  padding: 20px;
  padding-left: 15px;

  
}
.home_textarea{
  padding-top: 50px;
}
#home_help {
  margin: 0px;
}


</style>
