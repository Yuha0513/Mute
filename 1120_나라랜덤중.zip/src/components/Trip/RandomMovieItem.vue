<template>
  <div>
    <img :src="random.poster_path" class="random_poster">
    {{ random.title }}
  </div>
</template>

<script>
export default {
  name: 'RandomMovieItem',
  props: {
    random: Object,
  },
  data() {
    return {
      
    }
  }

}
</script>

<style>
.random_poster {
  width: 500px;
  height: 700px;
}
</style>