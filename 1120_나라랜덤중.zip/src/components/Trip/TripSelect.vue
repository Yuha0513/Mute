<template>
  <div>
    <div class="select_country"
      v-for="(country, index) in countries"
      :key="index"  
    >
      <button @click="selectCountry(country, $event)">{{ country }}</button>
    </div>
    <div class="country_movies">
      {{ countrymovie }}
    </div>
  </div>
</template>

<script>
export default {
  name: 'TripSelect',
  computed: {
    countries() {
      return this.$store.state.country
    },
    countrymovie() {
      return this.$store.state.country_movie
    }
  },
  methods: {
    selectCountry(event) {
      this.$store.dispatch('selectCountry', event)
      this.$store.dispatch('countryMovie')

    }
  }
}
</script>

<style>

</style>